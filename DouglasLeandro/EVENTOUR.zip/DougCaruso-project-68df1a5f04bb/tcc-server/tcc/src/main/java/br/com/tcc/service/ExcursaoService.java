package br.com.tcc.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;

import br.com.tcc.DTO.Excursao;
import br.com.tcc.entity.ExcursaoEntity;
import br.com.tcc.entity.UsuarioEntity;
import br.com.tcc.repository.ExcursaoRepository;
import br.com.tcc.repository.UsuarioRepository;

public class ExcursaoService {

	private ExcursaoRepository repository = new ExcursaoRepository();
	private UsuarioRepository usuarioRepository = new UsuarioRepository();
	private ModelMapper mapper = new ModelMapper();

	public ExcursaoService() {
		mapper.getConfiguration().setAmbiguityIgnored(true);
	}
	
	public void save(Excursao excursao) {
		UsuarioEntity usuario = usuarioRepository.getById(excursao.getUsuario().getId());
		ExcursaoEntity entity = mapper.map(excursao, ExcursaoEntity.class);
		entity.setUsuario(usuario);
		repository.save(entity);
	}

	public void update(Excursao excursao) {
		ExcursaoEntity entity = mapper.map(excursao, ExcursaoEntity.class);
		repository.update(entity);
	}

	public void delete(Integer id) {
		repository.delete(id);
	}

	public Excursao getById(Integer id) {
		return mapper.map(repository.getById(id), Excursao.class);
	}

	public List<Excursao> getByEventId(Integer id) {
		List<ExcursaoEntity> list = repository.getByEventId(id);
		List<Excursao> excursoes = new ArrayList<Excursao>();
		for (ExcursaoEntity entity : list) {
			excursoes.add(mapper.map(entity, Excursao.class));
		}
		return excursoes;
	}

	public List<Excursao> getByUserId(Integer id) {
		UsuarioEntity usuario = usuarioRepository.getById(id);
		List<ExcursaoEntity> list;
		if (usuario.getTipo()) {
			list = repository.findByUser(usuario);
		} else {
			list = repository
					.findByUserId(usuario.getUsuarioId())
					.stream()
					.map(ue-> ue.getExcursao())
					.collect(Collectors.toList());
		}
		List<Excursao> excursoes = new ArrayList<Excursao>();
		for (ExcursaoEntity entity : list) {
			excursoes.add(mapper.map(entity, Excursao.class));
		}
		return excursoes;
	}

}
