package br.com.tcc.service;

import org.modelmapper.ModelMapper;

import br.com.tcc.DTO.UsuarioExcursao;
import br.com.tcc.entity.UsuarioExcursaoEntity;
import br.com.tcc.repository.UsuarioExcursaoRepository;

public class UsuarioExcursaoService {

	private UsuarioExcursaoRepository repository = new UsuarioExcursaoRepository();
	private ModelMapper mapper = new ModelMapper();

	public UsuarioExcursaoService() {
		mapper.getConfiguration().setAmbiguityIgnored(true);
	}
	
	public void save(UsuarioExcursao usuarioExcursao) {
		UsuarioExcursaoEntity entity = mapper.map(usuarioExcursao, UsuarioExcursaoEntity.class);
		repository.save(entity);
	}

	public void delete(Integer id) {
		repository.delete(id);
	}
	
	public void update(UsuarioExcursao usuarioExcursao) {
		UsuarioExcursaoEntity entity = mapper.map(usuarioExcursao, UsuarioExcursaoEntity.class);
		repository.update(entity);
	}
}
