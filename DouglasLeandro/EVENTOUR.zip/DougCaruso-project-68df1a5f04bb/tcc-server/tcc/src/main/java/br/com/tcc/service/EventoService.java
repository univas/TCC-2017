package br.com.tcc.service;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;

import br.com.tcc.DTO.Evento;
import br.com.tcc.entity.EventoEntity;
import br.com.tcc.repository.EventoRepository;

public class EventoService {

	private EventoRepository repository = new EventoRepository();
	private ModelMapper mapper = new ModelMapper();

	public EventoService() {
		mapper.getConfiguration().setAmbiguityIgnored(true);
	}
	
	public void save(Evento evento) {
		EventoEntity entity = mapper.map(evento, EventoEntity.class);
		repository.save(entity);
	}

	public void update(Evento excursao) {
		EventoEntity entity = mapper.map(excursao, EventoEntity.class);
		repository.update(entity);
	}

	public void delete(Integer id) {
		repository.delete(id);
	}

	public Evento getById(Integer id) {
		return mapper.map(repository.getById(id), Evento.class);
	}

	public List<Evento> getAll() {
		List<EventoEntity> list = repository.listAll();
		List<Evento> eventos = new ArrayList<Evento>();
		for (EventoEntity entity : list) {
			eventos.add(mapper.map(entity, Evento.class));
		}
		return eventos;
	}

}
