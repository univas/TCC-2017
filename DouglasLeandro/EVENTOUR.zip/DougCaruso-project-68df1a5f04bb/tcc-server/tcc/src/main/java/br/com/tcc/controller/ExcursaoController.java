package br.com.tcc.controller;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import br.com.tcc.DTO.Excursao;
import br.com.tcc.service.ExcursaoService;

@Path("/excursoes")
public class ExcursaoController {

	private ExcursaoService excursaoService = new ExcursaoService();
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public void save(Excursao excursao) {
		excursaoService.save(excursao);
	}
	
	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public void update(Excursao excursao) {
		excursaoService.update(excursao);
	}
	
	@DELETE
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public void delete(@PathParam("id") Integer id) {
		excursaoService.delete(id);
	}
	
	@GET
	@Path("/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Excursao getById(@PathParam("id") Integer id) {
		return excursaoService.getById(id);
	}
	
	@GET
	@Path("/evento/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Excursao> getByEvent(@PathParam("id") Integer id) {
		return excursaoService.getByEventId(id);
	}
	
	@GET
	@Path("/usuario/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Excursao> getByUserId(@PathParam("id") Integer id) {
		return excursaoService.getByUserId(id);
	}

}
