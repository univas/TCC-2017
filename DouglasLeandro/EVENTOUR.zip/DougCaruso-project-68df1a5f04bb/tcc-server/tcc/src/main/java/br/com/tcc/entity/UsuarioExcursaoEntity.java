package br.com.tcc.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="usuarios_excursoes")
public class UsuarioExcursaoEntity {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="usuario_excursao_id")
	private int usuarioExcursaoId;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="excursao_id", nullable=false)
	private ExcursaoEntity excursao;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="usuario_id", nullable=false)
	private UsuarioEntity usuario;

	@Column(name="comprovante", nullable=true)
	private String comprovante;
	
	public UsuarioExcursaoEntity() {
	}

	public int getUsuarioExcursaoId() {
		return this.usuarioExcursaoId;
	}

	public void setUsuarioExcursaoId(int usuarioExcursaoId) {
		this.usuarioExcursaoId = usuarioExcursaoId;
	}

	public ExcursaoEntity getExcursao() {
		return this.excursao;
	}

	public void setExcursao(ExcursaoEntity excursao) {
		this.excursao = excursao;
	}

	public UsuarioEntity getUsuario() {
		return this.usuario;
	}

	public void setUsuario(UsuarioEntity usuario) {
		this.usuario = usuario;
	}

	public String getComprovante() {
		return comprovante;
	}

	public void setComprovante(String comprovante) {
		this.comprovante = comprovante;
	}

}