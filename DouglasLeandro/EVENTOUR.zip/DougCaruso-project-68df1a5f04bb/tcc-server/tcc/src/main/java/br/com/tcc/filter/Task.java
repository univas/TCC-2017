package br.com.tcc.filter;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseCredentials;

public class Task implements ServletContextListener {

	public void contextInitialized(ServletContextEvent contextEvent) {
		System.out.println("Inicializando firebase app");
		try {
			InputStream serviceAccount = this.getClass().getClassLoader().getResourceAsStream("META-INF/firebase-adminsdk.json");
			FirebaseOptions options = new FirebaseOptions.Builder()
					.setCredential(FirebaseCredentials.fromCertificate(serviceAccount))
					.setDatabaseUrl("https://project-d41da.firebaseio.com").build();

			FirebaseApp.initializeApp(options);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void contextDestroyed(ServletContextEvent e) {

	}
}