package br.com.tcc.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import br.com.tcc.entity.EventoEntity;

public class EventoRepository extends Repository {

	private EntityManager entityManager;

	public EventoRepository() {
		entityManager = getEntityManager();
	}

	public void save(EventoEntity entity) {
		entityManager.getTransaction().begin();
		entityManager.persist(entity);
		entityManager.getTransaction().commit();
	}

	public void update(EventoEntity entity) {
		entityManager.getTransaction().begin();
		entityManager.merge(entity);
		entityManager.getTransaction().commit();
	}

	public EventoEntity getById(Integer id) {
		EventoEntity entity = entityManager.find(EventoEntity.class, id);
		return entity;
	}

	public void delete(Integer id) {
		entityManager.getTransaction().begin();
		Query query = entityManager.createQuery("DELETE from EventoEntity e WHERE e.id = :id");
		query.setParameter("id", id);
		query.executeUpdate();
		entityManager.getTransaction().commit();
	}
	
	@SuppressWarnings("unchecked")
	public List<EventoEntity> listAll() {
		return this.entityManager.createQuery("SELECT e FROM EventoEntity e WHERE e.data >= CURDATE() ORDER BY e.data").getResultList();
	}

}
