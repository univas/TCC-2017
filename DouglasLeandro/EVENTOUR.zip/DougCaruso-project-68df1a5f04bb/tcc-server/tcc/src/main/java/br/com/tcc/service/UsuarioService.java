package br.com.tcc.service;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;

import br.com.tcc.DTO.Usuario;
import br.com.tcc.DTO.UsuarioExcursao;
import br.com.tcc.entity.UsuarioEntity;
import br.com.tcc.entity.UsuarioExcursaoEntity;
import br.com.tcc.repository.UsuarioRepository;

public class UsuarioService {

	private UsuarioRepository repository = new UsuarioRepository();
	private ModelMapper mapper = new ModelMapper();

	public UsuarioService() {
		mapper.getConfiguration().setAmbiguityIgnored(true);
	}

	public List<Usuario> getAll() {
		List<UsuarioEntity> list = repository.getAll();
		List<Usuario> usuarios = new ArrayList<Usuario>();
		for (UsuarioEntity usuarioEntity : list) {
			Usuario usuario = mapper.map(usuarioEntity, Usuario.class);
			usuarios.add(usuario);
		}
		return usuarios;
	}

	public Usuario save(Usuario usuario) {
		UsuarioEntity entity = mapper.map(usuario, UsuarioEntity.class);
		entity = repository.save(entity);
		return mapper.map(entity, Usuario.class);
	}

	public Usuario update(Usuario usuario) {
		UsuarioEntity entity = mapper.map(usuario, UsuarioEntity.class);
		entity = repository.update(entity);
		return mapper.map(entity, Usuario.class);
	}

	public Usuario getById(Integer id) {
		return mapper.map(repository.getById(id), Usuario.class);
	}

	public void delete(Integer id) {
		repository.delete(id);
	}

	public List<UsuarioExcursao> getByExcursaoId(Integer id) {
		List<UsuarioExcursaoEntity> list = repository.getByExcursaoId(id);
		List<UsuarioExcursao> usuarios = new ArrayList<UsuarioExcursao>();
		for (UsuarioExcursaoEntity usuarioExcursaoEntity : list) {
			UsuarioExcursao usuario = mapper.map(usuarioExcursaoEntity, UsuarioExcursao.class);
			usuario.getExcursao().setUsuario(null);
			usuario.setExcursao(null);
			usuarios.add(usuario);
		}
		return usuarios;
	}

	public Usuario getByEmail(String email) {
		UsuarioEntity entity = repository.getByEmail(email);
		Usuario usuario = mapper.map(entity, Usuario.class);
		return usuario;
	}

}
