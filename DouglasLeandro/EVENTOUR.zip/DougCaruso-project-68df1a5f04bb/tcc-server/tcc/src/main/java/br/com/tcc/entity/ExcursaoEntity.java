package br.com.tcc.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "excursoes")
public class ExcursaoEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "excursao_id")
	private int excursaoId;

	@Column(name = "cidade", nullable = false, length = 100)
	private String cidade;
	
	@Column(name = "data", nullable = false)
	@Temporal(TemporalType.DATE)
	private Date data;

	@Column(name = "hora", nullable = false)
	private String hora;

	@Column(name = "local", nullable = false, length = 100)
	private String local;
	
	@Column(name = "estado", nullable = false, length = 100)
	private String estado;
	
	@Column(name = "bairro", nullable = false, length = 100)
	private String bairro;

	@Column(name = "nome", nullable = false, unique = true, length = 100)
	private String nome;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "evento_id", nullable = false)
	private EventoEntity evento;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "usuario_id", nullable = false)
	private UsuarioEntity usuario;

	@Column(name = "imagem", nullable = true)
	private String imagem;

	public ExcursaoEntity() {
	}

	public int getExcursaoId() {
		return this.excursaoId;
	}

	public void setExcursaoId(int excursaoId) {
		this.excursaoId = excursaoId;
	}

	public String getCidade() {
		return this.cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public Date getData() {
		return this.data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public String getHora() {
		return this.hora;
	}

	public void setHora(String hora) {
		this.hora = hora;
	}

	public String getNome() {
		return this.nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public EventoEntity getEvento() {
		return this.evento;
	}

	public void setEvento(EventoEntity evento) {
		this.evento = evento;
	}

	public UsuarioEntity getUsuario() {
		return this.usuario;
	}

	public void setUsuario(UsuarioEntity organizador) {
		this.usuario = organizador;
	}

	public String getLocal() {
		return local;
	}

	public void setLocal(String local) {
		this.local = local;
	}

	public String getImagem() {
		return imagem;
	}

	public void setImagem(String imagem) {
		this.imagem = imagem;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

}