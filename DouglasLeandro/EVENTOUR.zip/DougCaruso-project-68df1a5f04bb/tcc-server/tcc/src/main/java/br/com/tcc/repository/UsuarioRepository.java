package br.com.tcc.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import br.com.tcc.entity.UsuarioEntity;
import br.com.tcc.entity.UsuarioExcursaoEntity;

public class UsuarioRepository extends Repository {

	private EntityManager entityManager;

	public UsuarioRepository() {
		entityManager = getEntityManager();
	}

	@SuppressWarnings("unchecked")
	public List<UsuarioEntity> getAll() {
		return entityManager.createQuery("SELECT u FROM UsuarioEntity u ORDER BY u.nome").getResultList();
	}

	public UsuarioEntity save(UsuarioEntity entity) {
		entityManager.getTransaction().begin();
		entityManager.persist(entity);
		entityManager.getTransaction().commit();
		return entity;
	}

	public UsuarioEntity update(UsuarioEntity entity) {
		entityManager.getTransaction().begin();
		entityManager.merge(entity);
		entityManager.getTransaction().commit();
		return entity;
	}

	public UsuarioEntity getById(Integer id) {
		UsuarioEntity entity = entityManager.find(UsuarioEntity.class, id);
		return entity;
	}

	public void delete(Integer id) {
		entityManager.getTransaction().begin();
		Query query = entityManager.createQuery("DELETE from UsuarioEntity u WHERE u.id = :id");
		query.setParameter("id", id);
		query.executeUpdate();
		entityManager.getTransaction().commit();
	}

	@SuppressWarnings("unchecked")
	public List<UsuarioExcursaoEntity> getByExcursaoId(Integer id) {
		String query = "SELECT ue FROM UsuarioExcursaoEntity ue WHERE ue.excursao.excursaoId = :id";
		List<UsuarioExcursaoEntity> list = entityManager.createQuery(query).setParameter("id", id).getResultList();
		return list;
	}

	public UsuarioEntity getByEmail(String email) {
		String query = "SELECT u FROM UsuarioEntity u WHERE u.email = :email";
		UsuarioEntity entity = (UsuarioEntity) entityManager.createQuery(query).setParameter("email", email).getSingleResult();
		return entity;
	}
}
