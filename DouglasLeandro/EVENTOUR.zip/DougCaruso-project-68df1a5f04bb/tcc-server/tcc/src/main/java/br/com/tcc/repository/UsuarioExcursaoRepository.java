package br.com.tcc.repository;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import br.com.tcc.entity.UsuarioExcursaoEntity;

public class UsuarioExcursaoRepository extends Repository {

	private EntityManager entityManager;

	public UsuarioExcursaoRepository() {
		entityManager = getEntityManager();
	}

	public void save(UsuarioExcursaoEntity entity) {
		entityManager.getTransaction().begin();
		entityManager.persist(entity);
		entityManager.getTransaction().commit();
	}

	public void update(UsuarioExcursaoEntity entity) {
		String query = "SELECT ue FROM UsuarioExcursaoEntity ue WHERE ue.excursao = :excursao AND ue.usuario = :usuario";
		UsuarioExcursaoEntity usuarioExcursaoEntity = (UsuarioExcursaoEntity) entityManager
				.createQuery(query)
				.setParameter("excursao", entity.getExcursao())
				.setParameter("usuario", entity.getUsuario())
				.getSingleResult();

		usuarioExcursaoEntity.setComprovante(entity.getComprovante());
		entityManager.getTransaction().begin();
		entityManager.merge(usuarioExcursaoEntity);
		entityManager.getTransaction().commit();
	}
	
	public void delete(Integer id) {
		entityManager.getTransaction().begin();
		Query query = entityManager.createQuery("DELETE from UsuarioExcursaoEntity ue WHERE ue.usuario.usuarioId = :id");
		query.setParameter("id", id);
		query.executeUpdate();
		entityManager.getTransaction().commit();
	}
}
