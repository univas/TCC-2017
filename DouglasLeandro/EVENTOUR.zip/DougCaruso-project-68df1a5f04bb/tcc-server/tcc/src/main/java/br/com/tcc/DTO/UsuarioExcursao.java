package br.com.tcc.DTO;

public class UsuarioExcursao {

	private int usuarioExcursaoId;

	private Excursao excursao;

	private Usuario usuario;

	private String comprovante;
	
	public UsuarioExcursao() {
	}

	public int getUsuarioExcursaoId() {
		return this.usuarioExcursaoId;
	}

	public void setUsuarioExcursaoId(int usuarioExcursaoId) {
		this.usuarioExcursaoId = usuarioExcursaoId;
	}

	public Excursao getExcursao() {
		return this.excursao;
	}

	public void setExcursao(Excursao excursao) {
		this.excursao = excursao;
	}

	public Usuario getUsuario() {
		return this.usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public String getComprovante() {
		return comprovante;
	}

	public void setComprovante(String comprovante) {
		this.comprovante = comprovante;
	}

}