package br.com.tcc.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import br.com.tcc.entity.ExcursaoEntity;
import br.com.tcc.entity.UsuarioEntity;
import br.com.tcc.entity.UsuarioExcursaoEntity;

public class ExcursaoRepository extends Repository {

	private EntityManager entityManager;
	
	public ExcursaoRepository() {
		entityManager = getEntityManager();
	}
	
	public void save(ExcursaoEntity entity) {
		entityManager.getTransaction().begin();
		entityManager.persist(entity);
		entityManager.getTransaction().commit();
	}

	public void update(ExcursaoEntity entity) {
		entityManager.getTransaction().begin();
		entityManager.merge(entity);
		entityManager.getTransaction().commit();
	}

	public ExcursaoEntity getById(Integer id) {
		ExcursaoEntity entity = entityManager.find(ExcursaoEntity.class, id);
		return entity;
	}

	public void delete(Integer id) {
		entityManager.getTransaction().begin();
		Query query = entityManager.createQuery("DELETE from ExcursaoEntity e WHERE e.id = :id");
		query.setParameter("id", id);
		query.executeUpdate();
		entityManager.getTransaction().commit();
	}
	
	@SuppressWarnings("unchecked")
	public List<ExcursaoEntity> listAll() {
		return entityManager.createQuery("SELECT e FROM ExcursaoEntity e ORDER BY e.data").getResultList();
	}

	@SuppressWarnings("unchecked")
	public List<ExcursaoEntity> getByEventId(Integer id) {
		String query = "SELECT e FROM ExcursaoEntity e WHERE e.evento.eventoId = :id";
		List<ExcursaoEntity> list = entityManager.createQuery(query).setParameter("id", id).getResultList();
		return list;
	}

	@SuppressWarnings("unchecked")
	public List<ExcursaoEntity> findByUser(UsuarioEntity usuario) {
		String query = "SELECT e FROM ExcursaoEntity e WHERE e.usuario.usuarioId = :id";
		List<ExcursaoEntity> list = entityManager.createQuery(query).setParameter("id", usuario.getUsuarioId()).getResultList();
		return list;
	}
	
	@SuppressWarnings("unchecked")
	public List<UsuarioExcursaoEntity> findByUserId(Integer id) {
		String query = "SELECT ue FROM UsuarioExcursaoEntity ue WHERE ue.usuario.usuarioId = :id";
		List<UsuarioExcursaoEntity> list = entityManager.createQuery(query).setParameter("id", id).getResultList();
		return list;
	}

}
