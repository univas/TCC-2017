package br.com.tcc.filter;

import java.io.IOException;
import java.util.List;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.Provider;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseToken;
import com.google.firebase.tasks.OnCompleteListener;
import com.google.firebase.tasks.OnFailureListener;
import com.google.firebase.tasks.OnSuccessListener;
import com.google.firebase.tasks.Task;

@Provider
public class AuthenticationFilter implements ContainerRequestFilter {

	private static final String AUTHORIZATION_PROPERTY = "Authorization";

	@Override
	public void filter(ContainerRequestContext requestContext) throws IOException { 
		Response ACCESS_DENIED = Response.status(Response.Status.UNAUTHORIZED).entity("401 - unauthorized").build();
		final MultivaluedMap<String, String> headers = requestContext.getHeaders();
		final List<String> authorization = headers.get(AUTHORIZATION_PROPERTY);
		if (authorization == null || authorization.isEmpty()) {
			requestContext.abortWith(ACCESS_DENIED);
			return;
		}
		String token = authorization.get(0);
		System.out.println(token);
		FirebaseAuth test = FirebaseAuth.getInstance();
		test.verifyIdToken(token)
				.addOnSuccessListener(new OnSuccessListener<FirebaseToken>() {
					@Override
					public void onSuccess(FirebaseToken decodedToken) {
						String uid = decodedToken.getUid();
						System.out.println("Success:" + uid);
					}
				}).addOnFailureListener(new OnFailureListener() {
					
					@Override
					public void onFailure(Exception e) {
						e.printStackTrace();
						System.out.println("Failure: " + e);
					}
				}).addOnCompleteListener(new OnCompleteListener<FirebaseToken>() {
					
					@Override
					public void onComplete(Task<FirebaseToken> arg0) {
						System.out.println("Complete:" + arg0);
					}
				});
	}
}