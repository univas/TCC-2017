package br.com.tcc.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="usuarios")
public class UsuarioEntity {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="usuario_id")
	private int usuarioId;

	@Column(name="cidade", nullable=true, length=100)
	private String cidade;

	@Column(name="cpf", nullable=true, length=14)
	private String cpf;

	@Column(name="telefone", nullable=true, length=15)
	private String telefone;
	
	@Column(name="email", nullable=false, length=255)
	private String email;

	@Column(name="endereco", nullable=true, length=255)
	private String endereco;

	@Column(name="estado", nullable=true, length=2)
	private String estado;

	@Column(name="identidade", nullable=true, length=15)
	private String identidade;

	@Column(name="nasc", nullable=true)
	@Temporal(TemporalType.DATE)
	private Date nasc;

	@Column(name="nome", nullable=true, length=100)
	private String nome;

	@Column(name="tipo", nullable=false)
	private Boolean tipo;

	@Column(name = "avatar", nullable = true)
	private String avatar;
	
	public UsuarioEntity() {
	}

	public int getUsuarioId() {
		return this.usuarioId;
	}

	public void setUsuarioId(int usuarioId) {
		this.usuarioId = usuarioId;
	}

	public String getCidade() {
		return this.cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getCpf() {
		return this.cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getEndereco() {
		return this.endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getEstado() {
		return this.estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getIdentidade() {
		return this.identidade;
	}

	public void setIdentidade(String identidade) {
		this.identidade = identidade;
	}

	public Date getNasc() {
		return this.nasc;
	}

	public void setNasc(Date nasc) {
		this.nasc = nasc;
	}

	public String getNome() {
		return this.nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getAvatar() {
		return avatar;
	}

	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public Boolean getTipo() {
		return tipo;
	}

	public void setTipo(Boolean tipo) {
		this.tipo = tipo;
	}

}