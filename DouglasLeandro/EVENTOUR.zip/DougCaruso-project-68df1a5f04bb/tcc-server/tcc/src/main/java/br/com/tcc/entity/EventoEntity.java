package br.com.tcc.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="eventos")
public class EventoEntity {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="evento_id")
	private int eventoId;
	
	@Column(name = "imagem", nullable = true)
	private String imagem;
	
	@Column(name="bandas", nullable=false, length=255)
	private String bandas;

	@Column(name="cidade", nullable=false, length=100)
	private String cidade;

	@Temporal(TemporalType.DATE)
	@Column(name="data", nullable=false)
	private Date data;

	@Column(name="hora", nullable=false)
	private String hora;

	@Column(name="local", nullable=false, length=100)
	private String local;

	@Column(name="nome", nullable=false, unique=true, length=100)
	private String nome;

	public EventoEntity() {
	}

	public int getEventoId() {
		return this.eventoId;
	}

	public void setEventoId(int eventoId) {
		this.eventoId = eventoId;
	}

	public String getBandas() {
		return this.bandas;
	}

	public void setBandas(String bandas) {
		this.bandas = bandas;
	}

	public String getCidade() {
		return this.cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public Date getData() {
		return this.data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public String getHora() {
		return this.hora;
	}

	public void setHora(String hora) {
		this.hora = hora;
	}

	public String getLocal() {
		return this.local;
	}

	public void setLocal(String local) {
		this.local = local;
	}

	public String getNome() {
		return this.nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getImagem() {
		return this.imagem;
	}

	public void setImagem(String imagem) {
		this.imagem = imagem;
	}
}