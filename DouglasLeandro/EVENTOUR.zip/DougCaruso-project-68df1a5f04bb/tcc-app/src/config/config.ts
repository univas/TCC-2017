export const Config = {
    api: {
        url: 'http://localhost:8080/tcc/api/'
    },
    path: {
        users: 'usuarios',
        events: 'eventos',
        tours: 'excursoes'
    },
    timeout: 15000
}