export const Messages = {
    invalid_credentials: "Email e/ou senha inválidos",
    invalid_email: "Email inválido",
    invalid_password: "A senha deve ter no mínimo 6 caracteres"
}