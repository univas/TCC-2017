import { Injectable } from '@angular/core';
import { RequestService } from '../../services/request.service';
import { Config } from "../../config/config";

@Injectable()
export class SignUpService {

    constructor(private requestService: RequestService) {
    }

    public save(data): Promise<any> {
        var url = Config.api.url.concat(Config.path.users);
        return this.requestService.post(url, data);
    }
}
