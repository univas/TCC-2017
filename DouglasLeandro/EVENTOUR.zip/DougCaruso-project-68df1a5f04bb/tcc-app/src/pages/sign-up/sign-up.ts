import { ViewController } from 'ionic-angular';
import { NavController, NavParams } from 'ionic-angular';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { SignUpService } from './sign-up-service';
import { AuthProvider } from '../../providers/auth/auth';
import { UsuarioService } from "../../services/usuario.service";
import { TabsPage } from "../tabs/tabs";
import { Constants } from "../../constants/constants";
import { LoadingCtrl } from "../../services/loading.service";
import { Toast } from "../../services/toast.service";

declare var google: any;

@Component({
  selector: 'page-sign-up',
  templateUrl: 'sign-up.html',
})
export class SignUpPage implements OnInit {

  private cadastroForm: FormGroup;
  private usuario: any;
  private titulo: string;
  autocompleteItems: any;
  acService: any;

  constructor(
    public viewCtrl: ViewController,
    private signUpService: SignUpService,
    public formBuilder: FormBuilder,
    public navCtrl: NavController,
    public navParams: NavParams,
    private auth: AuthProvider,
    private usuarioService: UsuarioService,
    private toast: Toast,
    private loading: LoadingCtrl
  ) {
    this.usuario = this.navParams.data;
    this.usuario.nasc = this.usuario.nasc === undefined ? new Date().toISOString() : this.usuario.nasc;
    this.titulo = this.usuario.id === undefined ? 'Cadastro de usuário' : 'Edição de perfil';
    this.usuario.tipo = this.usuario.id === undefined ? false : this.usuario.tipo;

    this.cadastroForm = this.formBuilder.group({
      nome: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.compose([Validators.required, Validators.pattern(Constants.EMAIL_REGEX)])]],
      telefone: ['', [Validators.required]],
      password: ['', [Validators.minLength(6), this.setPasswordRequired]],
      confirm: ['', [Validators.minLength(6), this.setPasswordRequired]],
      cidade: ['', [Validators.required, Validators.maxLength(100)]],
      estado: ['', [Validators.required, Validators.maxLength(2)]],
      endereco: ['', [Validators.required, Validators.maxLength(255)]],
      cpf: ['', [Validators.required, Validators.maxLength(14), Validators.minLength(14)]],
      identidade: ['', [Validators.required, Validators.minLength(8)]],
      nasc: '',
      tipo: ''
    })

  }

  ngOnInit() {
    this.acService = new google.maps.places.AutocompleteService();
    this.autocompleteItems = [];
  };

  setPasswordRequired() {
    if (this && this.usuario && !this.usuario.id) {
      this.cadastroForm.get('password').setValidators(Validators.required);
      this.cadastroForm.get('confirm').setValidators(Validators.required);
    }
  }

  dismiss() {
    this.viewCtrl.dismiss();
  }

  uppercase(event) {
    this.usuario.estado = event.target.value.toUpperCase();
  }

  register() {
    if (this.usuario && this.usuario.id) {
      this.update();
    } else {
      this.create();
    }
  }

  create() {
    let usuario = this.cadastroForm.value;
    usuario.lat = this.usuario.lat;
    usuario.lng = this.usuario.lng;
    var credenciais = ({ email: usuario.email, password: usuario.password });
    this.loading.show('Cadastrando...');
    this.signUpService.save(usuario).then((usuario) => {
      window.localStorage.setItem('usuario', JSON.stringify(usuario));
      this.registerFirebase(credenciais);
    }).catch((error) => {
      this.toast.show('Não foi possível realizar o cadastro. Tente novamente!');
      this.loading.hide();
    });
  }

  update() {
    this.loading.show('Atualizando perfil...');
    this.usuarioService.update(this.usuario).then((usuario) => {
      window.localStorage.setItem('usuario', JSON.stringify(usuario));
      this.dismiss();
      this.loading.hide();
    }).catch((error) => {
      this.toast.show('Não foi possível atualizar seus dados. Tente novamente!');
      this.loading.hide();
    });
  }

  private registerFirebase(credenciais) {
    this.auth.registerUser(credenciais).subscribe(registerData => {
      this.loginWithEmail(credenciais);
    }, error => {
      this.toast.show('Não foi possível realizar o cadastro no firebase.');
      this.loading.hide();
    });
  }

  private loginWithEmail(credenciais) {
    this.loading.show('Autenticando...');
    this.auth.loginWithEmail(credenciais).subscribe(authData => {
      window.localStorage.setItem('token', authData.refreshToken);
      this.navCtrl.setRoot(TabsPage);
      this.loading.hide();
    }, error => {
      this.toast.show('Email e/ou senha inválidos.');
      this.loading.hide();
    });
  }

  updateSearch() {
    if (this.usuario.endereco === '') {
      this.autocompleteItems = [];
      return;
    }
    let config = {
      types: ["address"],
      input: this.usuario.endereco,
      componentRestrictions: { country: 'BR' }
    }
    this.acService.getPlacePredictions(config, (predictions, status) => {
      this.autocompleteItems = [];
      if (status !== google.maps.places.PlacesServiceStatus.OK) {
        this.autocompleteItems.push({ description: 'Endereco não encontrado' });
        return;
      }
      this.autocompleteItems = this.autocompleteItems.concat(predictions);
    });
  }

  chooseItem(item: any) {
    if (!item.terms) {
      return;
    }
    this.usuario.endereco = item.terms[0].value;
    if (item.terms.length === 4) {
      this.usuario.cidade = item.terms[1].value;
      this.usuario.estado = item.terms[2].value;
    } else if (item.terms.length === 5) {
      this.usuario.cidade = item.terms[2].value;
      this.usuario.estado = item.terms[3].value;
    }
    this.autocompleteItems = [];
  }
}