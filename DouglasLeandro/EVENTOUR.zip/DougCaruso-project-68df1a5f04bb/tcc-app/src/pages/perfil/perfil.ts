import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { AuthProvider } from '../../providers/auth/auth';
import { LoginPage } from '../login/login';
import { Toast } from '../../services/toast.service';
import { LoadingCtrl } from '../../services/loading.service';
import { UsuarioService } from '../../services/usuario.service';
import { SignUpPage } from '../sign-up/sign-up';
import { Upload } from '../../services/upload.service';
import { AlertCtrl } from '../../services/alert.service';

@Component({
  selector: 'page-perfil',
  templateUrl: 'perfil.html',
})
export class PerfilPage {

  private file: File;
  private avatar: any;
  private usuario: any;
  private passageiro: any;

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    private auth: AuthProvider,
    private toast: Toast,
    private loadingCtrl: LoadingCtrl,
    private usuarioService: UsuarioService,
    private uploadService: Upload,
    private alert: AlertCtrl
  ) {
    if (this.navParams.data.usuarioExcursaoId) {
      this.passageiro = this.navParams.data;
      this.usuario = this.passageiro.usuario;
    }
  }

  ionViewDidEnter() {
    if (!this.passageiro) {
      this.loadUsuario();
    }
  }

  ionViewDidLeave() {
    this.avatar = undefined;
    this.passageiro = undefined;
  }

  onImage(event) {
    this.file = event.target.files[0];
    if (this.file) {
      const reader = new FileReader();
      reader.readAsDataURL(this.file);
      reader.onload = () => {
        this.usuario.avatar = reader.result;
      }
    }
  }

  upload() {
    if (this.file) {
      var uploadTask = this.uploadService.uploadImage(this.file, this.usuario.id, "perfil");
      uploadTask.on('state_changed', (result) => {
        this.loadingCtrl.show('Fazendo upload da imagem...');
      }, (error) => {
        this.toast.show("Não foi possível salvar a imagem. Tente novamente!");
        this.loadingCtrl.hide();
      }, () =>  {
        this.usuario.avatar = uploadTask.snapshot.downloadURL;
        this.salvar();
        return undefined;
      });
    } else {
      this.toast.show('Selecione uma imagem!');
    }
  }

  salvar() {
    this.usuarioService.update(this.usuario).then((usuario) => {
      window.localStorage.setItem('usuario', JSON.stringify(usuario));
      this.loadingCtrl.hide();
      this.toast.show('Imagem salva com sucesso!');
    }).catch((error) => {
      this.toast.show('Não foi possível salvar a imagem. Tente novamente!');
      this.loadingCtrl.hide();
    });
  }

  sair() {
    this.alert.show('Sair', 'Você deseja sair da aplicação?', () => this.logout());
  }

  logout() {
    this.auth.sair().subscribe(result => {
      this.navCtrl.setRoot(LoginPage);
    }, error => {
      this.toast.show('Não foi possível desconectar sua conta.');
    });
  }

  editarPerfil() {
    this.navCtrl.push(SignUpPage, this.usuario);
  }

  loadUsuario() {
    this.usuario = JSON.parse(window.localStorage.getItem('usuario'));
    if (!this.usuario.id) {
      this.loadingCtrl.show('Carregando perfil...');
      this.usuarioService.getUserByEmail(this.usuario.email).then((usuario) => {
        this.usuario = usuario;
        window.localStorage.setItem('usuario', JSON.stringify(usuario));
        this.loadingCtrl.hide();
      }).catch((error) => {
        this.loadingCtrl.hide();
        this.toast.show('Não foi possível carregar os dados do seu perfil. Tente novamente!');
      });
    } else {
      this.loadingCtrl.hide();
    }
  }
}
