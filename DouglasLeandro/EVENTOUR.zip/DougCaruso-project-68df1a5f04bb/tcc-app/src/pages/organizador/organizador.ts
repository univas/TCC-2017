import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { CadastroExcursao } from "../cadastro-excursao/cadastro-excursao";
import { OrganizadorService } from "./organizador.service";
import { UsuarioExcursao } from "../usuario-excursao/usuario-excursao";
import { LoginPage } from "../login/login";
import { AuthProvider } from "../../providers/auth/auth";
import { Toast } from "../../services/toast.service";
import { LoadingCtrl } from '../../services/loading.service';
import { AlertCtrl } from '../../services/alert.service';
import { UsuarioService } from '../../services/usuario.service';
import { EventoExcursao } from '../evento-excursao/evento-excursao';

@Component({
  selector: 'organizador-page',
  templateUrl: 'organizador.html'
})
export class Organizador {

  private excursoes: any;
  private selecionado: any;
  private usuario: any;

  constructor(
    public navCtrl: NavController,
    private organizadorService: OrganizadorService,
    private toast: Toast,
    private auth: AuthProvider,
    private loadingCtrl: LoadingCtrl,
    private alert: AlertCtrl,
    private usuarioService: UsuarioService
  ) {
  }

  ionViewWillLeave() {
    if (this.selecionado) {
      document.getElementById(this.selecionado.id.toString()).classList.remove('item-selected');
      this.selecionado = undefined;
    }
  }

  ionViewDidEnter() {
    this.loadingCtrl.show('Carregando excursões...');
    this.usuario = JSON.parse(window.localStorage.getItem('usuario'));
    if (!this.usuario.id) {
      this.usuarioService.getUserByEmail(this.usuario.email).then((usuario) => {
        window.localStorage.setItem('usuario', JSON.stringify(usuario));
        this.listarExcursoes();
      }).catch((error) => {
        this.loadingCtrl.hide();
        this.toast.show('Não foi possível carregar as excursões. Tente novamente!');
      });
    } else {
      this.listarExcursoes();
    }
  }

  listarExcursoes() {
    this.organizadorService.getByUser(this.usuario.id).then((excursoes) => {
      this.excursoes = excursoes;
      this.loadingCtrl.hide();
    }).catch((error) => {
      this.loadingCtrl.hide();
      this.toast.show('Não foi possível carregar as excursões. Tente novamente!');
    });
  }

  deletarExcursao() {
    this.alert.show('Remover excursão', 'Deseja realmente remover esta excursão?', () => this.onConfirm());
  }

  private onConfirm() {
    this.loadingCtrl.show('Removendo excursão...');
    this.organizadorService.delete(this.selecionado.id).then(() => {
      this.excursoes = this.excursoes.filter(item => { return item.id != this.selecionado.id });
      this.loadingCtrl.hide();
      this.selecionado = undefined;
      this.toast.show('Excursão removida com sucesso!');
    }).catch((error) => {
      this.loadingCtrl.hide();
      this.toast.show('Não foi possível remover a excursão. Tente novamente!');
    });
  }

  editarExcursao() {
    this.navCtrl.push(CadastroExcursao, { excursao: this.selecionado });
  }

  active(excursao) {
    if (this.usuario.tipo) {
      this.selecionado = excursao;
      document.getElementById(excursao.id).classList.add('item-selected');
    }
  }

  onTap(excursao) {
    if (!this.usuario.tipo) {
      this.navCtrl.push(EventoExcursao, {excursao: excursao, participando: true});
      return;
    } else if (!this.selecionado) {
      this.navCtrl.push(UsuarioExcursao, excursao);
      return;
    }
    if (this.selecionado.id === excursao.id) {
      document.getElementById(excursao.id).classList.remove('item-selected');
      this.selecionado = undefined;
    } else {
      document.getElementById(this.selecionado.id.toString()).classList.remove('item-selected');
      document.getElementById(excursao.id).classList.add('item-selected');
      this.selecionado = excursao;
    }
  }

  sair() {
    this.alert.show('Sair', 'Você deseja sair da aplicação?', () => this.logout());
  }

  logout() {
    this.auth.sair().subscribe(result => {
      this.navCtrl.setRoot(LoginPage);
    }, error => {
      this.toast.show('Não foi possível desconectar sua conta.');
    });
  }

}
