import { Injectable } from '@angular/core';

import { RequestService } from '../../services/request.service';
import { Config } from "../../config/config";

@Injectable()
export class OrganizadorService {

    constructor(private requestService: RequestService) {

    }

    public delete(id): Promise<any> {
        var url = Config.api.url.concat(Config.path.tours).concat(`/${id}`);
        return this.requestService.delete(url);
    }

    public getByUser(id): Promise<any> {
        var url = Config.api.url.concat(Config.path.tours).concat(`/usuario/${id}`);
        return this.requestService.get(url);
    }
}