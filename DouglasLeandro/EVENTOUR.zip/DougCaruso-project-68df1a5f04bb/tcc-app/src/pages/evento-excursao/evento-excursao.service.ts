import { Injectable } from '@angular/core';

import { RequestService } from '../../services/request.service';
import { Config } from "../../config/config";

@Injectable()
export class EventoExcursaoService {

    constructor(private requestService: RequestService) {

    }

    public save(data): Promise<any> {
        var url = Config.api.url.concat(Config.path.users).concat('/excursao');
        return this.requestService.post(url, data);
    }

    public enviar(data) {
        var url = Config.api.url.concat(Config.path.users).concat('/usuario/excursao');
        return this.requestService.put(url, data);
    }
}