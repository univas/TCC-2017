import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { EventoExcursaoService } from "./evento-excursao.service";
import { SignUpPage } from "../sign-up/sign-up";
import { Toast } from "../../services/toast.service";
import { Upload } from '../../services/upload.service';
import { LoadingCtrl } from '../../services/loading.service';
import { AlertCtrl } from '../../services/alert.service';

@Component({
  selector: 'page-evento-excursao',
  templateUrl: 'evento-excursao.html',
})
export class EventoExcursao {

  private excursao: any;
  private usuario: any;
  private participando: boolean;
  private file: File;
  private usuarioExcursao: any;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private eventoExcursaoService: EventoExcursaoService,
    private toast: Toast,
    private uploadService: Upload,
    private loadingCtrl: LoadingCtrl,
    private alert: AlertCtrl
  ) {
    this.excursao = this.navParams.data.excursao;
    this.excursao.hora = this.excursao.hora.substring(0,5);
    this.participando = this.navParams.data.participando;
  }

  ionViewDidEnter() {
    this.usuario = JSON.parse(window.localStorage.getItem('usuario'));
  }

  participarExcursao() {
    if (!this.usuario.telefone || !this.usuario.email || !this.usuario.identidade) {
      this.navCtrl.push(SignUpPage, this.usuario);
      this.toast.show('Para continuar finalize seu cadastro!');
      return;
    }
    this.usuarioExcursao = { usuario: this.usuario, excursao: this.excursao }
    this.eventoExcursaoService.save(this.usuarioExcursao).then(() => {
      this.toast.show('Você foi adicionado a excursão. Envie o comprovante de pagamento para o organizador!');
      this.navCtrl.pop();
    }).catch((error) => {
      this.toast.show('Não foi possível adicioná-lo a excursão. Verifique se você já está participando e tente novamente!');
    });
  }

  onImage(event) {
    this.file = event.target.files[0];
    this.alert.show('Enviar comprovante', 'O Comprovante selecionado está correto?', () => this.enviarComprovante());
  }

  enviar() {
    document.getElementById('comprovante').click();
  }

  private enviarComprovante() {
    var uploadTask = this.uploadService.uploadImage(this.file, this.usuario.id, "comprovante");
    uploadTask.on('state_changed', (result) => {
      this.loadingCtrl.show('Enviando comprovante...');
    }, (error) => {
      this.toast.show('Não foi possível enviar o comprovante. Tente novamente!');
      this.loadingCtrl.hide();
    }, () => {
      this.usuarioExcursao = { usuario: this.usuario, excursao: this.excursao };
      this.usuarioExcursao.comprovante = uploadTask.snapshot.downloadURL;
      this.eventoExcursaoService.enviar(this.usuarioExcursao).then(() => {
        this.toast.show('Comprovante enviado com sucesso!');
        this.loadingCtrl.hide();
        this.navCtrl.pop();
      }).catch(() => {
        this.toast.show('Não foi possível enviar o comprovante. Tente novamente!');
      })
      return undefined;
    });
  }

}