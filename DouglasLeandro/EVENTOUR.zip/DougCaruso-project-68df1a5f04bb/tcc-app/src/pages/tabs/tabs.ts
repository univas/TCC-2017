import { Organizador } from './../organizador/organizador';
import { Busca } from './../busca/busca';
import { Component } from '@angular/core';
import { PerfilPage } from '../perfil/perfil';

@Component({
  templateUrl: 'tabs.html'
})
export class TabsPage {

  tab1Root = Busca;
  tab2Root = Organizador;
  tab3Root = PerfilPage;

  constructor() {

  }
}
