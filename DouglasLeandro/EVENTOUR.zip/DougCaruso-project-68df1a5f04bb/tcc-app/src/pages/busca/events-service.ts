import { Injectable } from '@angular/core';

import { RequestService } from '../../services/request.service';
import { Config } from "../../config/config";

@Injectable()
export class EventsService {

    constructor(private requestService: RequestService) {

    }

    public getAll(): Promise<any> {
        var url = Config.api.url.concat(Config.path.events);
        return this.requestService.get(url);
    }
}