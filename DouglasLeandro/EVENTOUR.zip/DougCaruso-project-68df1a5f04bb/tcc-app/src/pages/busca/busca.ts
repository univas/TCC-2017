import { Evento } from './../evento/evento';
import { Component, ViewChild } from '@angular/core';
import { NavController } from 'ionic-angular';
import { EventsService } from './events-service';
import { FiltroService } from "../../services/filtro.service";
import { AuthProvider } from "../../providers/auth/auth";
import { LoginPage } from "../login/login";
import { Toast } from "../../services/toast.service";
import { LoadingCtrl } from "../../services/loading.service";
import { AlertCtrl } from '../../services/alert.service';


@Component({
  selector: 'busca-page',
  templateUrl: 'busca.html'
})
export class Busca {

  private eventos = [];
  private filtroEventos = [];
  private filtro: string;
  private hideSearch: boolean;

  @ViewChild('searchbar') searchbar;

  constructor(
    public navCtrl: NavController,
    private eventService: EventsService,
    private toast: Toast,
    private filtroService: FiltroService,
    private auth: AuthProvider,
    private loading: LoadingCtrl,
    private alert: AlertCtrl
  ) {
    this.hideSearch = true;
  }

  showSearch() {
    this.hideSearch = false;
    setTimeout(() => {
      this.searchbar.setFocus();
    })
  }

  onInput() {
    this.filtroEventos = this.filtroService.filtrar(this.eventos, this.filtro);
  }

  onCancel() {
    this.filtro = '';
    this.onInput();
    this.hideSearch = true;
  }

  ionViewDidEnter() {
    this.loading.show('Carregando eventos...');
    this.eventService.getAll().then((eventos) => {
      this.eventos = eventos;
      this.filtroEventos = eventos;
      this.loading.hide();
    }).catch((error) => {
      this.toast.show('Não foi possível carregar os eventos. Tente novamente!');
      this.loading.hide();
    });
  }

  abrirEvento(evento) {
    this.navCtrl.push(Evento, evento);
  }

  sair() {
    this.alert.show('Sair', 'Você deseja sair da aplicação?', () => this.logout());
  }

  logout() {
    this.auth.sair().subscribe(result => {
      this.navCtrl.setRoot(LoginPage);
    }, error => {
      this.toast.show('Não foi possível desconectar sua conta.');
    });
  }
}
