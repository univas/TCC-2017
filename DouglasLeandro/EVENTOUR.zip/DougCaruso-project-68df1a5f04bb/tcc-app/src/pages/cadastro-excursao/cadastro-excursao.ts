import { Component, OnInit } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { CadastroExcursaoService } from "./cadastro-excursao.service";
import { Toast } from "../../services/toast.service";
import { LoadingCtrl } from '../../services/loading.service';
import { Upload } from '../../services/upload.service';

declare var google: any;

@Component({
  selector: 'page-cadastro-excursao',
  templateUrl: 'cadastro-excursao.html',
})
export class CadastroExcursao implements OnInit {
  private evento: any;
  private excursao: any;
  autocompleteItemsCidade: any;
  autocompleteItemsLocal: any;
  acService: any;
  private filePhoto: File;
  private titulo: string;
  private usuario: any;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public cadastroService: CadastroExcursaoService,
    private toast: Toast,
    private loading: LoadingCtrl,
    private uploadService: Upload
  ) {
    this.evento = this.navParams.data.evento;
    this.excursao = this.navParams.data.excursao || {};
    this.titulo = this.excursao.id ? 'Edição de excursão' : 'Cadastro de excursão';
    this.excursao.data = this.excursao.data === undefined ? this.evento.data : this.excursao.data;
    this.excursao.hora = this.excursao.hora === undefined ? new Date().toLocaleTimeString() : this.excursao.hora;
  }

  ngOnInit(): void {
    this.acService = new google.maps.places.AutocompleteService();
    this.autocompleteItemsCidade = [];
    this.autocompleteItemsLocal = [];
    this.usuario = JSON.parse(window.localStorage.getItem('usuario'));
  }

  salvar() {
    if(this.filePhoto)
      this.uploadImage();
    else
      this.continue();
  }

  uploadImage() {
    if (this.filePhoto) {
      var uploadTask = this.uploadService.uploadImage(this.filePhoto, this.usuario.id, "excursao");
      uploadTask.on('state_changed', (result) => {
        this.loading.show('Fazendo upload da imagem...');
      }, (error) => {
        this.loading.hide();
        this.toast.show("Não foi possível cadastrar a excursão. Tente novamente!");
      }, () => {
        this.excursao.imagem = uploadTask.snapshot.downloadURL;
        this.continue();
        return undefined;
      });
    } else if (this.excursao.imagem) {
      this.continue();
    }
  }

  continue() {
    if (!this.excursao.id || this.excursao.id === 0) {
      this.loading.show('Cadastrando excursão...');
      this.cadastrar();
    } else {
      this.loading.show('Atualizando excursão...');
      this.editar();
    }
  }

  cadastrar() {
    this.excursao.evento = this.evento;
    this.excursao.usuario = this.usuario;
    this.cadastroService.save(this.excursao).then(() => {
      this.toast.show('Excursão cadastrada com sucesso!');
      this.navCtrl.popToRoot();
    }).catch((error) => {
      this.toast.show('Não foi possível cadastrar a excursão. Tente novamente!');
      this.loading.hide();
    })
  }

  editar() {
    this.cadastroService.update(this.excursao).then(() => {
      this.toast.show('Excursão alterada com sucesso!');
      this.navCtrl.popToRoot();
    }).catch((error) => {
      this.toast.show('Não foi possível alterar a excursão. Tente novamente!');
      this.loading.hide();      
    });
  }

  cancelar() {
    this.navCtrl.pop();
  }

  atualizarBuscaCidade() {
    if (this.excursao.cidade === '') {
      this.autocompleteItemsCidade = [];
      return;
    }
    let config = {
      types: ['(cities)'],
      input: this.excursao.cidade,
      componentRestrictions: { country: 'BR' }
    }
    this.acService.getPlacePredictions(config, (predictions, status) => {
      this.autocompleteItemsCidade = [];
      if (status !== google.maps.places.PlacesServiceStatus.OK) {
        this.autocompleteItemsCidade.push({ description: 'Cidade não encontrada' });
        return;
      }
      this.autocompleteItemsCidade = this.autocompleteItemsCidade.concat(predictions);
    });
  }

  atualizarBuscaLocal() {
    if (this.excursao.local === '') {
      this.autocompleteItemsLocal = [];
      return;
    }
    let config = {
      types: ["address"],
      input: this.excursao.local,
      componentRestrictions: { country: 'BR' }
    }
    this.acService.getPlacePredictions(config, (predictions, status) => {
      this.autocompleteItemsLocal = [];
      if (status !== google.maps.places.PlacesServiceStatus.OK) {
        this.autocompleteItemsLocal.push({ description: 'Local não encontrado' });
        return;
      }
      this.autocompleteItemsLocal = this.autocompleteItemsLocal.concat(predictions);
    });
  }

  escolhaItemCidade(item: any) {
    if (!item.terms) {
      return;
    }
    this.excursao.cidade = item.terms[0].value;
    this.autocompleteItemsCidade = [];
  }

  escolhaItemLocal(item: any) {
    if (!item.terms) {
      return;
    }
    this.excursao.local = item.terms[0].value;
    if (item.terms.length === 4) {
      this.excursao.cidade = item.terms[1].value;
      this.excursao.bairro = '';
      this.excursao.estado = item.terms[2].value;
    } else if (item.terms.length === 5) {
      this.excursao.bairro = item.terms[1].value;
      this.excursao.cidade = item.terms[2].value;
      this.excursao.estado = item.terms[3].value;
    }
    this.autocompleteItemsLocal = [];
  }

  onImage(event) {
    this.filePhoto = event.target.files[0];
  }
}
