import { Injectable } from '@angular/core';

import { RequestService } from '../../services/request.service';
import { Config } from "../../config/config";

@Injectable()
export class CadastroExcursaoService {

    constructor(private requestService: RequestService) {

    }

    public update(data): Promise<any> {
        var url = Config.api.url.concat(Config.path.tours);
        return this.requestService.put(url, data);
    }

    public save(data): Promise<any> {
        var url = Config.api.url.concat(Config.path.tours);
        return this.requestService.post(url, data);
    }
}