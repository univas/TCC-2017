import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { FiltroService } from "../../services/filtro.service";
import { UsuarioService } from "../../services/usuario.service";
import { Toast } from "../../services/toast.service";
import { PerfilPage } from '../perfil/perfil';

@Component({
  selector: 'page-usuario-excursao',
  templateUrl: 'usuario-excursao.html',
})
export class UsuarioExcursao {

  private excursao: any;
  private passageiros = [];
  private filtroPassageiros = [];
  private filtro: string;
  private hideSearch: boolean;

  @ViewChild('searchbar') searchbar;

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    private toast: Toast,
    private filtroService: FiltroService,
    private usuarioService: UsuarioService
  ) {
    this.hideSearch = true;
  }

  showSearch() {
    this.hideSearch = false;
    setTimeout(() => {
      this.searchbar.setFocus();
    })
  }

  onInput() {
    var lista = this.filtroService.filtrar(this.passageiros.map(passageiro => { return passageiro.usuario }), this.filtro);
    this.filtroPassageiros = lista.map(item => {
      var usuario = { usuario: item }
      return usuario;
    });
  }

  onCancel() {
    this.filtro = '';
    this.onInput();
    this.hideSearch = true;
  }

  ionViewDidEnter() {
    this.excursao = this.navParams.data;
    this.usuarioService.getByExcursao(this.excursao).then((passageiros) => {
      this.passageiros = passageiros;
      this.filtroPassageiros = passageiros;
    }).catch((error) => {
      this.toast.show('Não foi possível carregar os passageiros. Tente novamente!');
    });
  }

  onTap(passageiro) {
    this.navCtrl.push(PerfilPage, passageiro);
  }
}
