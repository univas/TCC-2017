import { BuscaExcursao } from './../busca-excursao/busca-excursao';
import { Component } from '@angular/core';
import { NavController, NavParams, FabContainer } from 'ionic-angular';
import { CadastroExcursao } from "../cadastro-excursao/cadastro-excursao";
import { SignUpPage } from "../sign-up/sign-up";
import { Toast } from "../../services/toast.service";

@Component({
  selector: 'page-evento',
  templateUrl: 'evento.html',
})

export class Evento {

  private evento: any;
  private usuario: any;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private toast: Toast
  ) {
    this.setEvento();
    this.usuario = JSON.parse(window.localStorage.getItem('usuario'));
  }

  setEvento() {
    let evento = this.navParams.data;
    evento.bandas = evento.bandas.split(';');
    this.evento = evento;
  }

  buscarExcursao(fab: FabContainer) {
    this.navCtrl.push(BuscaExcursao, this.evento);
    fab.close();
  }

  cadastrarExcursao(fab: FabContainer) {
    if (!this.usuario.nome) {
      this.navCtrl.push(SignUpPage, this.usuario);
      this.toast.show('Para continuar finalize seu cadastro!');
    } else {
      this.navCtrl.push(CadastroExcursao, { evento: this.evento });
    }
    fab.close();
  }

}
