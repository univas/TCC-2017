import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import * as firebase from 'firebase/app';
import { Toast } from '../../services/toast.service';

@Component({
  selector: 'page-esqueceu-senha',
  templateUrl: 'esqueceu-senha.html',
})
export class EsqueceuSenhaPage {

  email: string;
  authFire = firebase.auth();

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public toast: Toast
  ) {

  }

  redefinirSenha(){
    if (!this.email) {
      this.toast.show('Preencha o campo email');
      return;
    }

    this.authFire.sendPasswordResetEmail(this.email).then((resposta) => {
      this.toast.show('E-mail de redefinição de senha enviado');
      this.navCtrl.pop();
    }).catch(error => {
      if (error.message == "The email address is badly formatted.") {
        this.toast.show("Email inválido")
      } else if (error.message == "There is no user record corresponding to this identifier. The user may have been deleted."){
        this.toast.show("Usuário não encontrado. Verifique o endereço de email e tente novamente.")
      } else {
        this.toast.show("Erro ao enviar email de redefinição de senha. Tente novamente")
      }
    });
  }

}
