import { Component } from '@angular/core';
import { ModalController, NavController, NavParams, Platform } from 'ionic-angular';
import { AngularFireAuth } from 'angularfire2/auth';
import * as firebase from 'firebase/app';
import { SignUpPage } from './../sign-up/sign-up'
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { AuthProvider } from '../../providers/auth/auth';
import { TabsPage } from "../tabs/tabs";
import { SignUpService } from "../sign-up/sign-up-service";
import { Constants } from "../../constants/constants";
import { Toast } from "../../services/toast.service";
import { LoadingCtrl } from '../../services/loading.service';
import { Facebook } from '@ionic-native/facebook'
import { EsqueceuSenhaPage } from '../esqueceu-senha/esqueceu-senha';

@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

  loginForm: FormGroup;
  authFire = firebase.auth();

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public modalCtrl: ModalController,
    public formBuilder: FormBuilder,
    private afAuth: AngularFireAuth,
    private auth: AuthProvider,
    private toast: Toast,
    private signUpService: SignUpService,
    private loading: LoadingCtrl,
    private facebook: Facebook,
    private platform: Platform
  ) {
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.compose([Validators.required, Validators.pattern(Constants.EMAIL_REGEX)])]],
      password: ['', [Validators.required, Validators.minLength(6)]],
    })

  }

  login() {
    let login = this.loginForm.value;
    var credenciais = ({ email: login.email, password: login.password });
    this.loading.show('Autenticando...');
    this.auth.loginWithEmail(credenciais).subscribe(authData => {
      window.localStorage.setItem('token', authData.refreshToken);
    }, error => {
      this.toast.show('Email e/ou senha inválidos.');
      this.loading.hide();
    });
  }

  signInWithFacebook() {
    if (this.platform.is('cordova')) {
      this.facebook.login(['email', 'public_profile']).then(res => {
        const facebookCredential = firebase.auth.FacebookAuthProvider.credential(res.authResponse.accessToken);
        firebase.auth().signInWithCredential(facebookCredential).then(resp => {
          this.signUpService.save({email: resp.email, tipo: 0, avatar: resp.photoURL, nome: resp.displayName}).then((usuario) => {
            window.localStorage.setItem('usuario', JSON.stringify(usuario));
            window.localStorage.setItem('token', resp.refreshToken);
            this.navCtrl.setRoot(TabsPage);
          }).catch((error) => {
            if (!error._body.macth('uk_email')) {
              this.toast.show('Não foi possível realizar o cadastro. Tente novamente!');
            }
          });
        });
      })
    }
    else {
      this.afAuth.auth
        .signInWithPopup(new firebase.auth.FacebookAuthProvider())
        .then(res => {
          this.signUpService.save({email: res.user.email, tipo: 0}).then((usuario) => {            
            window.localStorage.setItem('usuario', JSON.stringify(usuario));
            window.localStorage.setItem('token', res.user.refreshToken);
            this.navCtrl.setRoot(TabsPage);
          }).catch((error) => {
            if (!error._body.macth('uk_email')) {
              this.toast.show('Não foi possível realizar o cadastro. Tente novamente!');
            }
          });
        })
    }
  }

  cadastrar() {
    const modal = this.modalCtrl.create(SignUpPage);
    modal.present();
  }

  esqueceuSenha() {
    this.navCtrl.push(EsqueceuSenhaPage);
  }
}
