import { Injectable } from '@angular/core';

import { RequestService } from '../../services/request.service';
import { Config } from "../../config/config";

@Injectable()
export class BuscaExcursaoService {

    constructor(private requestService: RequestService) {

    }

    public getByEvent(evento): Promise<any> {
        var url = Config.api.url.concat(Config.path.tours).concat(`/evento/${evento.id}`);
        return this.requestService.get(url);
    }

    public getByLatLng(pos): Promise<any> {
        var url = `https://maps.googleapis.com/maps/api/geocode/json?key=AIzaSyBZaKP5HkN7ikj7GKL7hW8YiakDB3Zql4Q&latlng=${pos.lat},${pos.lng}`;
        return this.requestService.get(url);
    }
}