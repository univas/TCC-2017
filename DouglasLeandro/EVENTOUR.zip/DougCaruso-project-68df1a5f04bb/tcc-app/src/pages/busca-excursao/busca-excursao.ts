import { Component, ViewChild, NgZone } from '@angular/core';
import { NavController, NavParams, AlertController } from 'ionic-angular';
import { EventoExcursao } from './../evento-excursao/evento-excursao';
import { BuscaExcursaoService } from "./busca-excursao.service";
import { FiltroService } from "../../services/filtro.service";
import { Toast } from "../../services/toast.service";
import { LoadingCtrl } from '../../services/loading.service';
import { Geolocation } from '@ionic-native/geolocation';


declare var google: any;

@Component({
  selector: 'page-busca-excursao',
  templateUrl: 'busca-excursao.html',
})
export class BuscaExcursao {

  private excursoes = [];
  private filtroExcursoes = [];
  private filtro: string;
  private evento: any;
  private hideSearch: boolean;
  private usuario: any;
  private isCurrentPosition: boolean;
  private disableLocate: boolean;
  private service = new google.maps.DistanceMatrixService();

  @ViewChild('searchbar') searchbar;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private toast: Toast,
    private buscaExcursaoService: BuscaExcursaoService,
    private filtroService: FiltroService,
    private loading: LoadingCtrl,
    private zone: NgZone,
    private geolocation: Geolocation,
    private alertCtrl: AlertController
  ) {
    this.hideSearch = true;
    this.evento = this.navParams.data;
    this.usuario = JSON.parse(window.localStorage.getItem('usuario'));
    if (!this.usuario.endereco) {
      this.disableLocate = true;
      this.isCurrentPosition = true;
      localStorage.setItem('isCurrent', this.isCurrentPosition.toString());
      this.showAlert();
    } else {
      this.disableLocate = false;
    }
  }

  showAlert() {
    let alert = this.alertCtrl.create({
      title: 'Alerta',
      message: 'Você ainda não informou seu endereço, a distância das excursões sera definida a partir do seu local atual.',
      buttons: ['Ok']
    });
    alert.present();
  }

  showSearch() {
    this.hideSearch = false;
    setTimeout(() => {
      this.searchbar.setFocus();
    })
  }

  onInput() {
    this.filtroExcursoes = this.filtroService.filtrar(this.excursoes, this.filtro, 'cidade');
  }

  onCancel() {
    this.filtro = '';
    this.onInput();
    this.hideSearch = true;
  }

  ionViewDidEnter() {
    this.isCurrentPosition = localStorage.getItem('isCurrent') === 'true' ? true : false;
    this.loading.show('Carregando a lista de excursões...');
    this.buscaExcursaoService.getByEvent(this.evento).then((excursoes) => {
      this.excursoes = excursoes;
      this.filtroExcursoes = excursoes;
      this.getPosition();
      this.loading.hide();
    }).catch((error) => {
      this.loading.hide();
      this.toast.show('Não foi possível carregar as excursões. Tente novamente!');
    })
  }

  activeLocation() {
    let isCurrent = localStorage.getItem('isCurrent') === 'true' ? true : false;
    this.isCurrentPosition = !isCurrent;
    localStorage.setItem('isCurrent', this.isCurrentPosition.toString());
    this.getPosition();
  }

  getPosition() {
    if (this.isCurrentPosition) {

      this.geolocation.getCurrentPosition().then((position) => {
        let pos = { lat: position.coords.latitude, lng: position.coords.longitude }        
        this.buscaExcursaoService.getByLatLng(pos).then((response) => {
          this.calcDistancia(response.results[0].formatted_address);
        });
      }).catch((error) => {
        this.toast.show('Não foi possível determinar sua localização. Tente novamente!');
      });
    } else {
      this.calcDistancia(`${this.usuario.endereco}, ${this.usuario.cidade} - ${this.usuario.estado}`);
    }
  }

  private calcDistancia(endereco) {
    this.filtroExcursoes.forEach((excursao, index) => {
      excursao.distancia = undefined;
      this.service.getDistanceMatrix({
        origins: [endereco],
        destinations: [`${excursao.local}, ${excursao.cidade} - ${excursao.estado}`],
        travelMode: 'WALKING',
      }, (response, status) => {
        if (status === 'OK') {
          this.zone.run(() => {
            let distancia = response.rows[0].elements[0].distance.value / 1000;
            excursao.distancia = distancia.toFixed(2) + ' Km';
            if (index === this.filtroExcursoes.length - 1) {
              this.ordenar();
            }
          });
        }
      });
    });
  }

  abrirDetalhesExcursao(excursao) {
    this.navCtrl.push(EventoExcursao, { excursao: excursao });
  }

  ordenar() {
    this.filtroExcursoes.sort((a, b) => {
      return parseFloat(a.distancia.replace(/\D/g, '')) - parseFloat(b.distancia.replace(/\D/g, ''));
    });
  }
}
