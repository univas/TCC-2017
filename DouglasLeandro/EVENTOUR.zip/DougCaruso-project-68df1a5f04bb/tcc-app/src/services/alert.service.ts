import { AlertController } from 'ionic-angular';
import { Injectable } from "@angular/core";

@Injectable()
export class AlertCtrl {

    constructor(
        public alertCtrl: AlertController
    ) {

    }

    show(title: string, message: string, onConfirm: Function, onCancel?: Function) {
        const alert = this.alertCtrl.create({
            title: title,
            message: message,
            buttons: [
              {
                text: 'Não',
                handler: () => onCancel ? onCancel() : () => {}
              },
              {
                text: 'Sim',
                handler: () => onConfirm()
              }
            ]
          });
          alert.present();
    }

}