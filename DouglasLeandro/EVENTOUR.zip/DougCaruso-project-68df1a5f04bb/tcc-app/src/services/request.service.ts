import { Headers, Http, RequestOptions } from '@angular/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/timeout'
import 'rxjs/add/operator/map';

import { Config } from "../config/config";

@Injectable()
export class RequestService {

    constructor(private http: Http) {

    }

    private getRequestOptions() {
        let options = new RequestOptions();
        let headers = new Headers({
            'authorization': localStorage.getItem('token'),
            'Content-Type': 'application/json; charset=UTF-8'
        })
        options.headers = headers;
        return options;
    }

    public get(url: string): Promise<any> {
        let options = this.getRequestOptions();
        if (url.match('googleapis')) {
            options = undefined;
        }
        return new Promise((resolve, reject) => {
            this.http.get(url, options)
                .timeout(Config.timeout)
                .map(res => res.json())
                .subscribe(data => {
                    resolve(data);
                }, (err) => {
                    reject(err);
                });
        })
    }

    public post(url: string, data: any): Promise<any> {
        const options = this.getRequestOptions();
        return new Promise((resolve, reject) => {
            this.http.post(url, data, options)
                .timeout(Config.timeout)
                .map(res => res.json())
                .subscribe(data => {
                    resolve(data);
                }, (err) => {
                    reject(err);
                });
        })
    }

    public put(url: string, data: any): Promise<any> {
        const options = this.getRequestOptions();
        return new Promise((resolve, reject) => {
            this.http.put(url, data, options)
                .timeout(Config.timeout)
                .map(res => res.json())
                .subscribe(data => {
                    resolve(data);
                }, (err) => {
                    reject(err);
                });
        })
    }

    public delete(url: string): Promise<any> {
        const options = this.getRequestOptions();
        return new Promise((resolve, reject) => {
            this.http.delete(url, options)
                .timeout(Config.timeout)
                .map(res => res.json())
                .subscribe(data => {
                    resolve(data);
                }, (err) => {
                    reject(err);
                });
        })
    }
}