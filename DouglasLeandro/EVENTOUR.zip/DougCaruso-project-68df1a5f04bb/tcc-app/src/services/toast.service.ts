import { ToastController } from 'ionic-angular';
import { Injectable } from "@angular/core";

@Injectable()
export class Toast {

  constructor(private toastCtrl: ToastController) {

  }

  show(message) {
    let toast = this.toastCtrl.create({
      message: message,
      duration: 5000,
      position: 'bottom'
    });

    toast.present();
  }

}