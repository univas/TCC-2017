import { Injectable } from '@angular/core';
import { Config } from "../config/config";
import { RequestService } from "./request.service";

@Injectable()
export class UsuarioService {

    constructor(
        private requestService: RequestService
    ) {

    }

    public update(usuario): Promise<any> {
        var url = Config.api.url.concat(Config.path.users);
        return this.requestService.put(url, usuario);
    }

    public getUserById(id): Promise<any> {
        var url = Config.api.url.concat(Config.path.users).concat(`/${id}`);
        return this.requestService.get(url);
    }

    getUserByEmail(email): Promise<any> {
        var url = Config.api.url.concat(Config.path.users).concat(`/usuario/${email}`);
        return this.requestService.get(url);
    }

    public getByExcursao(excursao): Promise<any> {
        var url = Config.api.url.concat(Config.path.users).concat(`/excursao/${excursao.id}`);
        return this.requestService.get(url);
    }
}