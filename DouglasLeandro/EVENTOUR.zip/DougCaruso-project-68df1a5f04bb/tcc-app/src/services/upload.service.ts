import { Injectable, Inject } from '@angular/core'
import * as firebase from 'firebase/app'
import 'firebase/storage'
import { FirebaseApp } from 'angularfire2';


@Injectable()
export class Upload {

  constructor(
    @Inject(FirebaseApp) public firebaseApp: firebase.app.App
  ) {

  }

  uploadImage(file: File, id: any, pasta: any): firebase.storage.UploadTask {
    const path = pasta === 'perfil' ? `/${pasta}/${id}/${pasta}_imagem` : `/${pasta}/${id}/${pasta}_${file.name}`
    return this.firebaseApp.storage()
      .ref()
      .child(path)
      .put(file, {
        contentType: 'image/jpeg'
      })
  }
}