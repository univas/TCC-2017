import { LoadingController, Loading } from 'ionic-angular';
import { Injectable } from "@angular/core";

@Injectable()
export class LoadingCtrl {

    private loading: Loading;

    constructor(private loadingCtrl: LoadingController) {

    }

    show(content) {
        if (this.loading && this.loading.instance) {
            this.loading.setContent(content);
        } else {
            this.loading = this.loadingCtrl.create({
                content: content,
                cssClass: 'custom-loading'
            });
        }
        this.loading.present();
    }

    hide() {
        if (this.loading) {
            this.loading.dismiss();
        }
    }
}