import { Directive, forwardRef, Attribute } from '@angular/core';
import { Validator, AbstractControl, NG_VALIDATORS } from '@angular/forms';

@Directive({
  selector: '[validateEqual]',
  providers: [{
    provide: NG_VALIDATORS, useExisting: forwardRef(() => EqualValidator), multi: true
  }]
})

export class EqualValidator implements Validator {
  constructor(
    @Attribute('validateEqual')
    public validateEqual: string
  ) {

  }

  validate(confirm: AbstractControl): { [key: string]: any } {
    let value = confirm.value;
    let password = confirm.root.get(this.validateEqual);
    if (password && value !== password.value) {
      return { validateEqual: false };
    }
    return null;
  }
}