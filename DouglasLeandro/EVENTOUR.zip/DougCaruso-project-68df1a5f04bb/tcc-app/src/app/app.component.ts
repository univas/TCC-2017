import { Component } from '@angular/core';
import { Platform } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { LoginPage } from '../pages/login/login';
import { AngularFireAuth } from "angularfire2/auth";
import { TabsPage } from "../pages/tabs/tabs";
import { UsuarioService } from "../services/usuario.service";
import { LoadingCtrl } from '../services/loading.service';

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  rootPage: any;

  constructor(
    platform: Platform, 
    statusBar: StatusBar, 
    splashScreen: SplashScreen, 
    public afAuth: AngularFireAuth,
    public usuarioService: UsuarioService,
    public loadingCtrl: LoadingCtrl
  ) {
    platform.ready().then(() => {
      afAuth.authState.subscribe(user => {
        if (user) {
          window.localStorage.setItem('token', user.refreshToken);
          this.usuarioService.getUserByEmail(user.email).then((user) => {
            window.localStorage.setItem('usuario', JSON.stringify(user));
            this.rootPage = TabsPage;
            statusBar.backgroundColorByHexString("#2e4779");            
          }).catch((error) => {
            window.localStorage.setItem('usuario', JSON.stringify({email: user.email}));
            this.rootPage = TabsPage;
            statusBar.backgroundColorByHexString("#2e4779");
          });
        } else {
          statusBar.backgroundColorByHexString("#c3c1c9");
          this.rootPage = LoginPage;
        }
      });
      splashScreen.hide();
    });
  }
}
