import { LoginPage } from './../pages/login/login';
import { EventoExcursao } from './../pages/evento-excursao/evento-excursao';
import { Organizador } from './../pages/organizador/organizador';
import { Busca } from './../pages/busca/busca';
import { BuscaExcursao } from './../pages/busca-excursao/busca-excursao';
import { Evento } from './../pages/evento/evento';
import { SignUpPage } from './../pages/sign-up/sign-up';
import { SignUpService } from './../pages/sign-up/sign-up-service';
import { AuthProvider} from '../providers/auth/auth';

import { NgModule, ErrorHandler } from '@angular/core';
import { HttpModule } from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { LongPressModule } from 'ionic-long-press';
import { MyApp } from './app.component';
import { TabsPage } from '../pages/tabs/tabs';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { Ionic2RatingModule } from 'ionic2-rating';

import { RequestService } from '../services/request.service';
import { EventsService } from '../pages/busca/events-service';

import { AngularFireModule } from 'angularfire2';
import {AngularFireDatabaseModule} from 'angularfire2/database'
import {AngularFireAuthModule} from 'angularfire2/auth'
import { CadastroExcursao } from "../pages/cadastro-excursao/cadastro-excursao";
import { BuscaExcursaoService } from "../pages/busca-excursao/busca-excursao.service";
import { CadastroExcursaoService } from "../pages/cadastro-excursao/cadastro-excursao.service";
import { OrganizadorService } from "../pages/organizador/organizador.service";
import { FiltroService } from "../services/filtro.service";
import { UsuarioService } from "../services/usuario.service";
import { EventoExcursaoService } from "../pages/evento-excursao/evento-excursao.service";
import { UsuarioExcursao } from "../pages/usuario-excursao/usuario-excursao";
import { LoadingCtrl } from "../services/loading.service";
import { Toast } from "../services/toast.service";
import { EqualValidator } from '../directives/validate-equal/validate-equal';
import { AlertCtrl } from '../services/alert.service';
import { Upload } from '../services/upload.service';
import { PerfilPage } from '../pages/perfil/perfil';
import { Ionic2MaskDirective } from "ionic2-mask-directive";
import { Geolocation } from '@ionic-native/geolocation';
import { Facebook } from '@ionic-native/facebook'
import { EsqueceuSenhaPage } from '../pages/esqueceu-senha/esqueceu-senha';



export const firebaseConfig = {
  apiKey: "AIzaSyADdgA9GRHjYfzdGSt5CR9teC_5QsYth0w",
  authDomain: "project-d41da.firebaseapp.com",
  databaseURL: "https://project-d41da.firebaseio.com",
  projectId: "project-d41da",
  storageBucket: "project-d41da.appspot.com",
  messagingSenderId: "1048680200163"
}

@NgModule({
  declarations: [
    BuscaExcursao,
    CadastroExcursao,
    Evento,
    EventoExcursao,
    LoginPage,
    MyApp,
    Organizador,
    SignUpPage,
    Busca,
    UsuarioExcursao,
    TabsPage,
    PerfilPage,
    EsqueceuSenhaPage,
    EqualValidator,
    Ionic2MaskDirective
  ],
  imports: [
    BrowserModule,
    HttpModule,
    IonicModule.forRoot(MyApp, {tabsPlacement: 'top', tabsHideOnSubPages: true}),
    Ionic2RatingModule,
    AngularFireModule.initializeApp(firebaseConfig),
    AngularFireDatabaseModule,
    AngularFireAuthModule,
    LongPressModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    BuscaExcursao,
    CadastroExcursao,
    Evento,
    EventoExcursao,
    LoginPage,
    MyApp,
    Organizador,
    SignUpPage,
    Busca,
    UsuarioExcursao,
    TabsPage,
    PerfilPage,
    EsqueceuSenhaPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    RequestService,
    EventsService,
    CadastroExcursaoService,
    SignUpService,
    BuscaExcursaoService,
    EventoExcursaoService,
    OrganizadorService,
    FiltroService,
    UsuarioService,
    Toast,
    LoadingCtrl,
    AuthProvider,
    AlertCtrl,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    Upload,
    Geolocation,
    Facebook
  ]
})
export class AppModule {}
