# IoTerm

Módulo - IoTermSensor - Sensor IoT

## Technology
- [Raspbian OS]
- [Eclipse Paho MQTT Client]
- [Adafruit ADT]
- [DHT_22 Humidity and temperature sensor]


