#!/bin/bash
mosquitto_sub -h localhost -t test -u ticleiton -P ti@cleiton -q 1
