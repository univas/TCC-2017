# IoTerm

Módulo - IoTermPlataform - Plataforma IoT

## Technology
- [Ubuntu Server 16.04.3 LTS]
- [Mosquitto MQTT Server]
- [Eclipse Paho MQTT Client]
- [MongoDB]
- [Flask Python Web Framework]
- [Nginx Web Server]
- [UWSGI]
