var altemp = document.getElementById('altemp').value;
alert({{alertas|count}});
console.log({{alertas|count}})
/*if (altemp=='temp') {
	document.getElementById("rp01temp").style.color = "white";
	document.getElementById("rp01temp").style.backgroundColor = "red";
}/*
//var alhumi = document.getElementById('alhumi').value;
/*if (true) {
	document.getElementById("rp01humi").style.color = "white";
	document.getElementById("rp01humi").style.backgroundColor = "red";
}*/