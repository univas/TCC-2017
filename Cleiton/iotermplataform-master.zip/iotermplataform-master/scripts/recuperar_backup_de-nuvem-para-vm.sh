#!/bin/bash
scp cleiton@www.ioterm.com.br/home/cleiton/iotermplataform/dump/* dump/iotdata/
mongorestore
