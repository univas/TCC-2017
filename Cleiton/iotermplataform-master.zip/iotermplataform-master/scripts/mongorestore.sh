mongorestore --collection configuracoes --db iotdata dump/iotdata/configuracoes.bson
